# WebApp using Streamlit

## BMI Calculator
- [Original Pyhton Console Project](https://thecleverprogrammer.com/2020/12/21/bmi-calculator-with-python/)

## Instructions to run the WebApp
- Install dependencies with `pip install -r requirements.txt`
- Now, run `streamlit run main.py` to run the WebApp on your local machine
- So.. What's your BMI, you can now calculate.