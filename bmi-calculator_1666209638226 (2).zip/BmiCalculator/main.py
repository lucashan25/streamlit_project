import streamlit as st

# title of the web-app
st.title("BMI Calculator")

def showBMI(height, weight):
    """
    function to calculate and show the BMI 
    and compliment over it.
    Parameters
    ----------
    height : number
        The height in centemeter
    weight : number
        The weight in kg
    """
    
    # validating height and weight
    if(height <= 0 or weight <= 0):
        st.error("enter valid details")
        return
    
    # convert height into meter
    height = height/100
    # calculate BMI using the formula
    BMI=weight/(height*height)
    # round off the float value to 2 decimal places
    BMI = round(BMI, 2)
    # writing the BMI to the Screen
    st.write("##### BMI :- ", BMI)
    
    # showing complement to the user based on the BMI value
    if(BMI<16):
        st.error("you are severely underweight")
    elif(BMI<=18.5):
        st.warning("you are underweight")
    elif(BMI<=25):
        st.success("you are Healthy")
    elif(BMI<=30):
        st.info("you are overweight")
    else: 
        st.error("you are severely overweight") 
    

def main():
    '''
    function that scaffolds Form field that holds the 
    height input, weight input and the calculate button
    '''
    with st.form(key="BMI_CALCULATOR_FORM"): 
        height = st.number_input("Height in centimeters:")
        weight = st.number_input("Weight in Kg: ")
        calculate_button = st.form_submit_button(label="Calculate BMI")
        if calculate_button:
            showBMI(height,weight)
            
if __name__ == "__main__":
    main()            


# code to hide the "inbuilt streamlit hamburger"
hide_st_style = """
            <style>
                #MainMenu {visibility: hidden;}
                header {visibility: hidden;}
            </style>
            """
st.markdown(hide_st_style, unsafe_allow_html=True)